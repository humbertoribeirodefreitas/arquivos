<?php 
session_start();
$XCStreamHostUrl = $_SESSION["server"];
$XClogoLinkval = "images/logo.png";
$XCcopyrighttextval = "";
$XCcontactUslinkval = "";
$XChelpLinkval = "";
$XClicenseIsval = "8nulled8";
$XClocalKey = "";
$XCsitetitleval = "";
?>