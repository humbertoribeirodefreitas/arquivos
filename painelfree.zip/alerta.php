<!-- Alerta Inicio -->
<div class="modal fade" id="alerta" tabindex="-1" role="dialog" aria-labelledby="Alerta" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-body">
      <button type="button" class="close" data-dismiss="modal" aria-label="Fechar">
          <span aria-hidden="true">&times;</span>
        </button>
        <div class="text-center">
        <h5 id="textoAlerta" class="h5"></h5> 
        </div>
      </div>
    </div>
  </div>
</div>
<!-- Alerta Fim-->